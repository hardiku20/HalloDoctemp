﻿using System;
using System.Collections.Generic;

namespace learning1.Models;

public partial class AspNetRole
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;
}
